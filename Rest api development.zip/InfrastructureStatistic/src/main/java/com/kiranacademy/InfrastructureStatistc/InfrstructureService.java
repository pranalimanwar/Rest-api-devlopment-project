package com.kiranacademy.InfrastructureStatistc;

import java.util.ArrayList;

import org.springframework.stereotype.Component;

import com.kiranacademy.InfrastructureStatistic.Bridge;


@Component
public class InfrstructureService {
	
	public ArrayList<Bridge> fetchBridgesInfo() {
		ArrayList<Bridge>alBridgeList=new ArrayList<Bridge>();
		
		Bridge bridge =new Bridge ("pune","11","500 mtr","50mtr")	;
		Bridge bridge1 =new Bridge ("pune","12","50 mtr","50mtr")	;
		Bridge bridge2 =new Bridge ("pune","13","600 mtr","50mtr")	;
		Bridge bridge3 =new Bridge ("pune","14","1000 mtr","50mtr")	;
		
		alBridgeList.add(bridge1);
		alBridgeList.add(bridge1);
		alBridgeList.add(bridge2);
		alBridgeList.add(bridge3);
		return alBridgeList;
	}
	
	
	
	
	

}
