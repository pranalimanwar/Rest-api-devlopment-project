package com.kiranacademy.InfrastructureStatistic;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component

public class InfrastructureDao {
	
	
	@Autowired

	 InfrastructureDao infrastructureDao;
	
		
		public ArrayList<Bridge> fetchBridgesInfo() {
			ArrayList<Bridge>alBridgeList=infrastructureDao.fetchBridgesInfo();
		
			return alBridgeList;
		}
}
