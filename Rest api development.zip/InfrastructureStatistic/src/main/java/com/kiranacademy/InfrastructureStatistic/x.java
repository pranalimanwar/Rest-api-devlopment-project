package com.kiranacademy.InfrastructureStatistic;

import org.springframework.stereotype.Component;

@Component

public class x {
	
     x(){
	System.err.println("I am in const--");
}
	
	
	
	void m2() {
		System.err.println (" X-----i am in m2");
	}

}
