package com.kiranacademy.InfrastructureStatistic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfrastructureStatisticApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfrastructureStatisticApplication.class, args);
	}

}
