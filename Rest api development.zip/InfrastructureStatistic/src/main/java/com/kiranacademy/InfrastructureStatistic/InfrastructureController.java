package com.kiranacademy.InfrastructureStatistic;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kiranacademy.InfrastructureStatistc.InfrstructureService;

@RestController
public class InfrastructureController {
	
	@Autowired
	
	  x xx = null;
	
@GetMapping("Checkcreation")
public void leanIOC()  {  

  xx.m2();

	
}
	
	
	
	@RequestMapping("bridgescount")
	
	int noofBridgesInIndia(){
		return 7856;
	}
	
	@PostMapping("addbridgeinfo")
	
public void addBridge(Bridge bridge) {
	System.out.println("bridge info ----+bridge");
	//jdbc to insrt into database
}
	
	
	@RequestMapping("bridgeinfo")
	
	Bridge fetchBridgeInfo() {
		
	Bridge bridge =new Bridge ("pune","11","500 mtr","50mtr")	;
		
	
		return bridge;
	}

	@RequestMapping("bridgesinfo")
	
	ArrayList<Bridge> fetchBridgesInfo() {
		InfrstructureService InfrstructureService = new InfrstructureService();
		ArrayList<Bridge>listBridges= InfrstructureService.fetchBridgesInfo();
	
		return listBridges;
	}
	


	@RequestMapping("bridgesnamebycity/{Cityname}/{Villagename}")
	
     	ArrayList<String>nameofBridgesinCity(@PathVariable String Cityname, @PathVariable String Villagename){
		
	System.out.println("I am in namebyBridgesinCity>>"    + Cityname );
	System.out.println("I am in namebyBridgesinCity>>"    + Villagename);
	
		ArrayList<String>listBridges=new ArrayList<String>();
		
		if(Cityname.equals("pune")) {

		listBridges.add("rajaram bride");
		listBridges.add("z bride");
		listBridges.add("dandekar bride");
		listBridges.add("warje bride");
		listBridges.add("navale bride");
		}
		
		else {
			listBridges.add("rajaram bride11");
			listBridges.add("z bride12");
			listBridges.add("dandekar bride13");
			listBridges.add("warje bride14");
			listBridges.add("navale bride15");
			
			
			
			
		}
	    return listBridges;
}	
	}

	
